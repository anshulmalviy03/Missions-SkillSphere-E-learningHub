import React from "react";

function FileUpload() {
  return <div>FileUpload</div>;
}

export default FileUpload;
