import React from "react";

function ManageCourses() {
  return (
    <div>
      <ul>
        <li>display table if courses(actions: update,delete)</li>
      </ul>
    </div>
  );
}

export default ManageCourses;
