let categories = [
  {
    courseCatId: 1,
    courseCatName: "Technology",
  },
  {
    courseCatId: 2,
    courseCatName: "Business",
  },
  {
    courseCatId: 3,
    courseCatName: "Helth",
  },
  {
    courseCatId: 4,
    courseCatName: "Language",
  },
];

export function getCourseCategories() {
  return categories;
}
