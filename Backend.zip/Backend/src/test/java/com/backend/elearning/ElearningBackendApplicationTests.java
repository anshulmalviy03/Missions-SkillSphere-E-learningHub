package com.backend.elearning;

import org.junit.jupiter.api.Test; 
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElearningBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
