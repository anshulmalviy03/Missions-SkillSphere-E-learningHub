package com.backend.elearning.services;


public interface CourseService {

	public String deleteCourseByID(Long id);

//	public List<Course> getAllCourseList();

}
