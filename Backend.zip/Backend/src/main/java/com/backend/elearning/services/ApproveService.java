package com.backend.elearning.services;

import java.util.List;

import com.backend.elearning.models.Aproove;

public interface ApproveService {

	public List<Aproove> getApproveListByUserID();
	
}
